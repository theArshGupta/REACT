//  key value pair: key should be unique
// const map1 = new Map();
// map1.set(3,90);
// map1.set("Rohit",45);
// map1.set(20,"Mohan");
// // map1.set("Rohit",40); value ko update karega

// map1.delete(3);


// // console.log(map1);
// console.log(map1.has("Rohit"));
// console.log(map1.size);
// map1.clear();
// console.log(map1);

const map1 = new Map([[4,"rohit"],["Moahn","rohan"],[30,9], [63,78]]);

// console.log(map1);
// for of loop
// for(let [key,value] of map1)
//     console.log(key, value);

// console.log(map1["4"]);

// Object:
// keys: string or symbol
// maps:
// keys:number, string, object


// Javascript code kaise execute hota hai......