<!-- Promise -->

The Promise object represents the eventual completion (or failure) of an asynchronous operation and its resulting value.


Cart
order
foodDetails
droplocation

Promises: 
1: pending

2: resolve
3: reject