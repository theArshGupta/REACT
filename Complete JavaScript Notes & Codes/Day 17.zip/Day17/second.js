
// greet();

// function greet(){
//     console.log("Hello World");
// }


//  
// Memory alloocatioN
//  greet: functuion code

//  Code execution





var meet = function(){
    console.log("Hello Meet");
}

meet();

// 


var x;

console.log(x);
x = 10;


// Memory allocation:
// meet: function

// Code execution phase:



