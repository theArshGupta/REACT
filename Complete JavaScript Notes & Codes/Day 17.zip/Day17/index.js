console.log(x);
console.log(y);
var x = 10;
let y = 20;

// Hoisting:


