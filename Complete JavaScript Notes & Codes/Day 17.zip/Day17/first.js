let z;
var x = undefined;
let y;
// const a;



console.log(x);
z = 50;
// console.log(y);
x = 10;
y = 20;
// a = 20;
// console.log(z);
console.log(x);