//  comparison operartor
// number to number

// let a1 = 1;
// let a2 = 2;
// console.log(a1==a2);
// == both are equal
// < less than, > greater than
// <= less than equal to , >= greater than equal to

// let num = 10;
// let str = "20";
// console.log(num==str);
// // Type conversion hga string to number

// let a1 = 10;
// let str1 = "10";
// console.log(a1==str1);


// // === type check, then compare the value
// console.log(a1===str1);


// let a2 = 30;
// let a3 = 40;
// console.log(a2===a3);

// null == undefined // true
// null=== undefined // false

// console.log(null==undefined);
// console.log(null===undefined);
// null can only be equivaklent to undefined ==
// console.log(null==0); 
// console.log(null<0);
// console.log(null>0);
// console.log(null<=0);
// console.log(null>=0);

// undefined comparison
// console.log(undefined==0);
// console.log(undefined<0);
// console.log(undefined>0);
// console.log(undefined<=0);
// console.log(undefined>=0);

// console.log(NaN==NaN);
// let str3 = "rohit"; 
// let str4 = "moahan"; 

// console.log(Number(str3));


// let abc1 = 123;
// let abc2 = "123";
// let abc3 = 123;
// console.log(abc1==abc2==abc3);

// console.log(undefined!=null); Homework

// 

// let age = 18;
// let money =420;
// console.log(age<18&&money>200);

// console.log(age>10 || money>200)

// console.log( !(age>10));

//  bitwise operartor
console.log(4&5);
console.log(11&14);
console.log(11|14);
console.log(5^7);
console.log(5<<3);
// 5 multiply by 2 power 3 // left shift
// 101.0000000000000000
// 101000.0000000

console.log(20>>2);
// right shift , 20 divided by 2 power 2
// 10100.000000
// 101.0000000


