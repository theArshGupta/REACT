<!-- Data store -->
1: Store the question
2: Option ko store karana: 4 option
3: Answer


obj1 = {
    question: "Who has the most centuries in international cricket?",
    options: ["Sachin Tendulkar", "Virat kohli", "Rickey pointing", "Jacque 
              kallis"]
    answer: "Sachin Tendulkar"          
}



obj2 = {} ... obj20

const questionBank =      [obj1,obj2,obj3,obj4,....obj20];

<!--  Selection 5 objects randomly -->




