// class Person{
//     constructor{

//     }
// }
// const obj = document.getElementById("first");
// obj.className = "Mohan";

