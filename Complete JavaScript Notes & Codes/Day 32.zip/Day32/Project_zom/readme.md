<!-- Data -->
1: Restaurant Image
2: Restaurant Name
3: Rating
4: Food_type
5: Price_for_two
6: Location
7: Distance_from_Customer_house
8: Offers
9: Alchol_serves
10: Restaurant_open_time
11: Restaurant_close_time


<!-- 100 dummy create karo -->



replaceChildren






<!-- Restaurant Info -->
1: IMG
2: Name
3: Rating
4: food_type
5: price_for_two
6: Location
7: Distance
8: Offers
9: Alchol
10: Restaurant_opening_time
11: Restaurant_closing_time

const obj = {
    img: "link",
    Name:"Sohan"
    food_type: "Indian",
    Rating: 4,
}


const restaurant = [100objects];