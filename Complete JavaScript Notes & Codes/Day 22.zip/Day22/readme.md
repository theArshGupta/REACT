<!-- Event Listener -->

<!-- Mouse Event -->
1: click
2: dblclick
3: mouseover
4: mousemove

<!-- Keyboard Event -->

1: keydown
2: keyup

<!-- Event Object -->
1: event
2: event.target
3: event.type
4: event.key
5: event.clientX
6: event.clientY