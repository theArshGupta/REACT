// if- else
// let age = 7;

// if(age>=18)
// {
//     console.log("Eligble for vote");
// }
// else
// {
//     console.log("Not Eligible for vote");
// }

// if else if else
// let age = 49;
// if(age<18)
// {
//     console.log("KID");
// }
// else if(age>45)
// {
//     console.log("OLD");
// }
// else
// {
//     console.log("YOUNG");
// }

//  Multiple condition: switch

// console.log(new Date().getDay());

// let day = "0";
// ===

// switch(day)
// {
//     case 0:
//         console.log("SUNDAY");
//         break;
//     case 1:
//         console.log("Monday");
//         break;
//     case 2:
//         console.log("Tuesday");
//         break;
//     case 3:
//         console.log("Wednesday");
//         break;
//     case 4:
//         console.log("Thursday");
//         break;
//     case 5:
//         console.log("Friday");
//         break;
//     case 6:
//         console.log("Saturday");
//         break;
//     default:
//         console.log("Not a Valid Day");
// }

//  loop : ek hi kaam ko baar baar karna

// i = 20
// for(let i=0;i<20;i++){

//     console.log("Hello Coder Army") 
// }

//  sum of first n number: 10 number
// let sum = 0;
// for(let i=1;i<=10;i++)
// {
//     sum+=i;
// }

// console.log(sum);






// 20 print karna hai

//  Nested for loop; Loop ke andar loop
// 12345
// 12345
// 12345
// 12345
// 12345
// 12345

// "/n , /t"
// Homework mein sochna hai

// for(let j=0;j<6;j++){
//    for(let i=1;i<=5;i++)
//    {
//     console.log(i);
//    }
// }

// for(let i=0;i<20;i++)
//     console.log(i);

//  scope ke baare mein: 
//  var 

// while loop
// for(let i=1;i<6;i++){

// }
// let i = 1;
// while(i<6)
// {
//     console.log(i);
//     i++;
// }

//  do-while loop 


// let arr = [10,30,40,50];
// for(let i=0;i<arr.length;i++)
// {
//     console.log(arr[i]);
// }

const obj = {
    name:"rohit",
    age:30,
    amount:420,
    city: "kotdwar"
}

// for in loop



// const key = Object.keys(obj);
// [ 'name', 'age', 'amount', 'city' ]
// for(let i=0;i<key.length;i++)
// {
//     console.log(obj[key[i]]);
// }









