console.log("hello Coder Army");

// control + ` it will open your terminal

// let const var
// var old tarike, don't use it.

let num = 10.5;
console.log(num);

let ar = "Rohit";
ar = "mohit";
console.log(ar)

const ids = 20;
console.log(ids);
// ids = 30; values can't be changed

var x = 10;
x=20;
console.log(x);