<!-- Event type -->
1: input
2: change
3: focus
<!-- focus: Does not bubble, so it needs to be directly attached to individual input elements.
focusin: Bubbles, so it can be attached to the form element for event delegation. -->
4: blur or focusout
5: click
<!-- 6: dbclick Explain later -->
7: submit
8: reset
9: FormData 



http://127.0.0.1:5501/03JS/Day24/index.html
http://127.0.0.1:5501/03JS/Day24/index.html?Name=Rohit&LastName=Negi&Age=23

<!-- keys=value
Name=Rohit
LastName=Negi
Age=23 -->