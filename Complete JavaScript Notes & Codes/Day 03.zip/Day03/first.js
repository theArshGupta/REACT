// // Number, string, boolean, null, undefined, Bigint, Symbol

// // Non Primitive data type
// // Array, Object, function

// // let n = 10;
// // let n2 = 20;
// // let n3 = 50;
// // array
// let arr = [10,20,50,"rohit","mohit"];
// console.log(typeof arr);

// // Object
// // key:value

// // let user_name = "Rohit";
// // let account_number: 31242314213;
// // let balance: 420;

// let obj = {
//    user_name: "Rohit",
//    account_number: 31242314213,
//    balance: 420
// }

// console.log(obj);

// // function

// let fun = function(){
//     console.log("Hello Coder army");
//     return 10;
// }

// console.log(fun());

// Type conversion

// let account_balance = "100";
// let num = Number(account_balance);

// console.log(typeof account_balance);
// console.log(typeof num);

// // Boolean convert to number
// let x = false;
// console.log(Number(x));

// let account = "100xs";
// let bal = "200s"
// console.log(Number(account));
// console.log(Number(bal));

// // null

// let x1 = null;
// console.log(Number(x1));

// // undefined
// let x2;
// console.log(Number(x2));

// // String ke andar convert
// let ab = 20;
// console.log(String(ab));

// let ax = false;
// // console.log(typeof false)

// console.log(String(ax));

// // Boolean
// let abc = " ";
// console.log(Boolean(abc));

// console.log((((6*(3+18))/6)-9));
// // 18+3-9
// // Divide Multiply Left to Right
// // Add sub Left to right

// // Modulous give reminder
// console.log(20%3); 

// // ++ increment operator , -- decrement operator
// let sum = 20;
// // --sum
// // sum++ post increment , sum-- post decrement
// // ++sum pre increment , --sum. pre decrement
// let total = ++sum;
// console.log(total);
// console.log(sum);



// Assignment operator

let x = 20;
x+=10;
// x = x+10;
console.log(x);
// x = x-10;
x/=10;
console.log(x);








