// call back function


// function names(fun){
//     console.log("Hello I am name");
//     fun();
// }

// const greet = function (){
//     console.log("I am call Back Function");
// }

// names(greet);


// names(function (){
//     console.log("I am call Back Function");
// });

// names(()=>{
//     console.log("I am call Back Function");
// });


// function fetchData(){
//     // bhut saara 
//     console.log("I am fetching data");
// }

// setInterval(fetchData,5000);





